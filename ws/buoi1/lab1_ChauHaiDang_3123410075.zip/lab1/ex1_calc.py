print("Basic calculator:")
a = int(input("Mời bạn nhập só a: "))
b = int(input("Mời bạn nhập só b: "))
print(f"a + b = {a+b}")
